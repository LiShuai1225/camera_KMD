package com.maniu.demo.dongtaidaili;

import android.content.Context;

public interface ProxyInterface {
    void buyWawa(Context context);
}
